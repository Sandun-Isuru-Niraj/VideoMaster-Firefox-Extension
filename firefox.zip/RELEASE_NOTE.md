v1.1

- New Icon Added
- Detection Methods Changed

v2.0

- No Title Bug Fixed